# Redis as a Primary Db

## Example in .NET 6